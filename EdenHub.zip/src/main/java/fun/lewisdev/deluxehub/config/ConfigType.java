package fun.lewisdev.deluxehub.config;

public enum ConfigType {

    SETTINGS,
    MESSAGES,
    COMMANDS,
    FEATURES, DATA

}
