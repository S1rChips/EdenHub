package fun.lewisdev.deluxehub.hook.hooks.head;

import org.bukkit.inventory.ItemStack;

public interface HeadHook {

    ItemStack getHead(String data);

}
