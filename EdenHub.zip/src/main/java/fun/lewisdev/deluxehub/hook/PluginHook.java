package fun.lewisdev.deluxehub.hook;

import fun.lewisdev.deluxehub.DeluxeHubPlugin;

public interface PluginHook {

    void onEnable(DeluxeHubPlugin plugin);

}
