package fun.lewisdev.deluxehub.cooldown;

public enum CooldownType {

    BLOCK_BREAK, BLOCK_PLACE, BLOCK_INTERACT, ITEM_DROP, ITEM_PICKUP, PLAYER_PVP, DOUBLE_JUMP, LAUNCHPAD, PLAYER_HIDER

}
