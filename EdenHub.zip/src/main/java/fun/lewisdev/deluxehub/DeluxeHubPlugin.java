package fun.lewisdev.deluxehub;

import cl.bgmp.minecraft.util.commands.exceptions.*;
import de.tr7zw.changeme.nbtapi.utils.MinecraftVersion;
import fun.lewisdev.deluxehub.action.ActionManager;
import fun.lewisdev.deluxehub.command.CommandManager;
import fun.lewisdev.deluxehub.config.ConfigManager;
import fun.lewisdev.deluxehub.config.ConfigType;
import fun.lewisdev.deluxehub.config.Messages;
import fun.lewisdev.deluxehub.cooldown.CooldownManager;
import fun.lewisdev.deluxehub.hook.HooksManager;
import fun.lewisdev.deluxehub.inventory.InventoryManager;
import fun.lewisdev.deluxehub.module.ModuleManager;
import fun.lewisdev.deluxehub.module.ModuleType;
import fun.lewisdev.deluxehub.module.modules.hologram.HologramManager;
import fun.lewisdev.deluxehub.tags.rtg.EdenTags;
import fun.lewisdev.deluxehub.tags.rtg.TagCommand;
import fun.lewisdev.deluxehub.tags.rtg.TagListener;
import fun.lewisdev.deluxehub.tags.rtg.TagPlaceholder;
import fun.lewisdev.deluxehub.utility.TextUtil;
import fun.lewisdev.deluxehub.utility.UpdateChecker;
import org.bstats.bukkit.MetricsLite;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;

public class DeluxeHubPlugin extends JavaPlugin {

    private EdenTags edenTags;
    private TagCommand tagCommand;  // <-- تعریف متغیر

    private static final int BSTATS_ID = 3151;

    private ConfigManager configManager;
    private ActionManager actionManager;
    private HooksManager hooksManager;
    private CommandManager commandManager;
    private CooldownManager cooldownManager;
    private ModuleManager moduleManager;
    private InventoryManager inventoryManager;

    @Override
    public void onEnable() {
        long start = System.currentTimeMillis();

        saveDefaultConfig();
        saveAllResources();

        configManager = new ConfigManager();
        configManager.loadFiles(this);

        sendStartupMessage();

        edenTags = new EdenTags(getDataFolder());

        tagCommand = new TagCommand(edenTags);  // مقداردهی

        if (getCommand("tags") != null) {
            getCommand("tags").setExecutor(tagCommand);
        } else {
            getLogger().warning("Command 'tags' is not defined in plugin.yml!");
        }

        getServer().getPluginManager().registerEvents(new TagListener(tagCommand), this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new TagPlaceholder(edenTags).register();
            getLogger().info("TagPlaceholder registered successfully.");
        } else {
            getLogger().warning("PlaceholderAPI not found, TagPlaceholder will not be registered.");
        }

        if (!isSpigotPresent()) return;

        MinecraftVersion.disableUpdateCheck();
        new MetricsLite(this, BSTATS_ID);

        hooksManager = new HooksManager(this);

        if (!getServer().getPluginManager().isPluginEnabled(this)) return;

        commandManager = new CommandManager(this);
        commandManager.reload();

        cooldownManager = new CooldownManager();
        inventoryManager = new InventoryManager();

        if (!hooksManager.isHookEnabled("HEAD_DATABASE")) {
            inventoryManager.onEnable(this);
        }

        moduleManager = new ModuleManager();
        moduleManager.loadModules(this);

        actionManager = new ActionManager(this);

        if (getConfigManager().getFile(ConfigType.SETTINGS).getConfig().getBoolean("update-check"))
            new UpdateChecker(this).checkForUpdate();

        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");

        getLogger().log(Level.INFO, "");
        getLogger().log(Level.INFO, "Successfully loaded in " + (System.currentTimeMillis() - start) + "ms");
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        moduleManager.unloadModules();
        inventoryManager.onDisable();
        configManager.saveFiles();
    }

    public void reload() {
        Bukkit.getScheduler().cancelTasks(this);
        HandlerList.unregisterAll(this);

        configManager.reloadFiles();

        inventoryManager.onDisable();
        inventoryManager.onEnable(this);

        getCommandManager().reload();

        moduleManager.loadModules(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, org.bukkit.command.Command cmd, String commandLabel, String[] args) {
        try {
            getCommandManager().execute(cmd.getName(), args, sender);
        } catch (CommandPermissionsException e) {
            Messages.NO_PERMISSION.send(sender);
        } catch (MissingNestedCommandException e) {
            sender.sendMessage(ChatColor.RED + e.getUsage());
        } catch (CommandUsageException e) {
            sender.sendMessage(ChatColor.RED + "Usage: " + e.getUsage());
        } catch (WrappedCommandException e) {
            if (e.getCause() instanceof NumberFormatException) {
                sender.sendMessage(ChatColor.RED + "Number expected, string received instead.");
            } else {
                sender.sendMessage(ChatColor.RED + "An internal error has occurred. See console.");
                e.printStackTrace();
            }
        } catch (CommandException e) {
            sender.sendMessage(ChatColor.RED + e.getMessage());
        }
        return true;
    }

    public HologramManager getHologramManager() {
        return (HologramManager) moduleManager.getModule(ModuleType.HOLOGRAMS);
    }

    public HooksManager getHookManager() {
        return hooksManager;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public CommandManager getCommandManager() {
        return commandManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public InventoryManager getInventoryManager() {
        return inventoryManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ActionManager getActionManager() {
        return actionManager;
    }

    private void saveAllResources() {
        File pluginFolder = getDataFolder();
        File menusFolder = new File(pluginFolder, "menus");

        if (!menusFolder.exists()) menusFolder.mkdirs();

        Set<String> menusOnly = new HashSet<>();
        menusOnly.add("serverselector.yml");
        menusOnly.add("lobbyselector.yml");
        menusOnly.add("profile.yml");

        try (JarFile jar = new JarFile(getFile())) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (entry.isDirectory()) continue;
                if (!name.endsWith(".yml")) continue;
                if (name.equals("plugin.yml")) continue;

                InputStream in = getResource(name);
                if (in == null) continue;

                String fileName = new File(name).getName();
                File outFile = menusOnly.contains(fileName)
                        ? new File(menusFolder, fileName)
                        : new File(pluginFolder, fileName);

                if (!outFile.exists()) {
                    Files.copy(in, outFile.toPath());
                    getLogger().info("Saved resource: " + fileName + " to " + outFile.getPath());
                }

                in.close();
            }
        } catch (IOException e) {
            getLogger().severe("Error copying resource files: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isSpigotPresent() {
        try {
            Class.forName("org.spigotmc.SpigotConfig");
            return true;
        } catch (ClassNotFoundException ex) {
            getLogger().severe("============= SPIGOT NOT DETECTED =============");
            getLogger().severe("EdenHub requires Spigot to run.");
            getLogger().severe("============= SPIGOT NOT DETECTED =============");
            getPluginLoader().disablePlugin(this);
            return false;
        }
    }

    private void sendStartupMessage() {
        String[] messages = {
                "&5&m------------------------------------------------------------------------------",
                "&d",
                "&d|-----------------    |             [-]   ---------    |-------------|",
                "&d|                     |                   |       |    |              ",
                "&d|                     |              |    |       |    |              ",
                "&d|                     |              |    |-------|    |              ",
                "&d|                     |              |    |            |-------------|",
                "&d|                     |---------|    |    |                          |",
                "&d|                     |         |    |    |                          |",
                "&d|                     |         |    |    |                          |",
                "&d|                     |         |    |    |                          |",
                "&d|                     |         |    |    |            |-------------|",
                "&d&m------------------------------------------------------------------------------",
                "&d",
        };
        for (String msg : messages) {
            getLogger().info(TextUtil.color(msg));
        }
    }
}
