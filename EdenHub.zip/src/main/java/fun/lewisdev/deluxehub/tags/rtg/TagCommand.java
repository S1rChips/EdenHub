package fun.lewisdev.deluxehub.tags.rtg;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TagCommand implements CommandExecutor {

    private final EdenTags edenTags;
    private final Map<UUID, Integer> playerPages = new HashMap<>();
    private final int tagsPerPage = 28;

    public TagCommand(EdenTags edenTags) {
        this.edenTags = edenTags;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command is only for players!");
            return true;
        }
        Player player = (Player) sender;
        openTagMenu(player, 1);
        return true;
    }

    public void openTagMenu(Player player, int page) {
        List<String> tags = edenTags.getTagsList();

        int totalPages = (int) Math.ceil(tags.size() / (double) tagsPerPage);
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        int startIndex = (page - 1) * tagsPerPage;
        int endIndex = Math.min(startIndex + tagsPerPage, tags.size());

        Inventory inv = Bukkit.createInventory(null, 54, ChatColor.AQUA + "" + ChatColor.BOLD + "Tags Menu " + ChatColor.GRAY + "- " + ChatColor.DARK_GRAY + "Page " + page);

        ItemStack border = new ItemStack(Material.GLASS);
        ItemMeta borderMeta = border.getItemMeta();
        borderMeta.setDisplayName(" ");
        border.setItemMeta(borderMeta);

        int[] borderSlots = {
                0,1,2,3,4,5,6,7,8,
                9,17,
                18,26,
                27,35,
                36,44,
                45,46,47,48,49,50,51,52,53
        };

        for (int slot : borderSlots) {
            inv.setItem(slot, border);
        }

        int[] tagSlots = {
                10,11,12,13,14,15,16,
                19,20,21,22,23,24,25,
                28,29,30,31,32,33,34,
                37,38,39,40,41,42,43
        };

        int slotIndex = 0;

        for (int i = startIndex; i < endIndex && slotIndex < tagSlots.length; i++) {
            String tagName = tags.get(i);
            String display = edenTags.getTagsConfig().getString("tags." + tagName + ".display", tagName);
            String permission = edenTags.getTagsConfig().getString("tags." + tagName + ".permission", "");

            if (permission.isEmpty() || player.hasPermission(permission)) {
                ItemStack tagItem = new ItemStack(Material.NAME_TAG);
                ItemMeta meta = tagItem.getItemMeta();
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', display));
                tagItem.setItemMeta(meta);

                inv.setItem(tagSlots[slotIndex], tagItem);
                slotIndex++;
            }
        }

        if (page > 1) {
            ItemStack prev = new ItemStack(Material.ARROW);
            ItemMeta meta = prev.getItemMeta();
            meta.setDisplayName(ChatColor.RED + "Previous Page");
            prev.setItemMeta(meta);
            inv.setItem(45, prev);
        }

        if (page < totalPages) {
            ItemStack next = new ItemStack(Material.ARROW);
            ItemMeta meta = next.getItemMeta();
            meta.setDisplayName(ChatColor.GREEN + "Next Page");
            next.setItemMeta(meta);
            inv.setItem(53, next);
        }

        player.openInventory(inv);
        playerPages.put(player.getUniqueId(), page);
    }

    public int getPlayerPage(UUID uuid) {
        return playerPages.getOrDefault(uuid, 1);
    }
}
