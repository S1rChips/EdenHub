//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package fun.lewisdev.deluxehub.tags.rtg;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public class TagPlaceholder extends PlaceholderExpansion {
    private final EdenTags edenTags;

    public TagPlaceholder(EdenTags edenTags) {
        this.edenTags = edenTags;
    }

    public boolean canRegister() {
        return this.edenTags != null;
    }

    public String getIdentifier() {
        return "edenhub";
    }

    public String getAuthor() {
        return "Chips";
    }

    public String getVersion() {
        return "1.0.0";
    }

    public String onPlaceholderRequest(Player player, String params) {
        if (player == null) {
            return "";
        } else {
            if (params.equalsIgnoreCase("tags")) {
                String selectedTag = this.edenTags.getSelectedTag(player.getUniqueId());
                if (selectedTag != null) {
                    return this.edenTags.getTagsConfig().getString("tags." + selectedTag + ".display", "");
                }
            }

            return "";
        }
    }
}
