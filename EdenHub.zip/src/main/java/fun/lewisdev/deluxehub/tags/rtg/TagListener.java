package fun.lewisdev.deluxehub.tags.rtg;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class TagListener implements Listener {

    private final TagCommand tagCommand;

    public TagListener(TagCommand tagCommand) {
        this.tagCommand = tagCommand;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        Player player = (Player) event.getWhoClicked();

        if (!event.getView().getTitle().startsWith(ChatColor.AQUA + "" + ChatColor.BOLD + "Tags Menu " + ChatColor.GRAY + "- " + ChatColor.DARK_GRAY + "Page ")) return;

        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || !clickedItem.hasItemMeta()) {
            event.setCancelled(true);
            return;
        }

        String displayName = clickedItem.getItemMeta().getDisplayName();
        UUID playerUUID = player.getUniqueId();
        int currentPage = tagCommand.getPlayerPage(playerUUID);

        // دکمه صفحه بعدی
        if (displayName.equals(ChatColor.GREEN + "Next Page")) {
            event.setCancelled(true);
            tagCommand.openTagMenu(player, currentPage + 1);
            return;
        }
        // دکمه صفحه قبلی
        else if (displayName.equals(ChatColor.RED + "Previous Page")) {
            event.setCancelled(true);
            tagCommand.openTagMenu(player, currentPage - 1 < 1 ? 1 : currentPage - 1);
            return;
        }

        // کلیک روی قاب
        if (clickedItem.getType() == Material.GLASS) {
            event.setCancelled(true);
            return;
        }

        // کلیک روی تگ (انتخاب تگ)
        event.setCancelled(true);

        // اینجا انتخاب تگ رو هندل کن (مثلا به پلیر پیام بده)
        player.sendMessage(ChatColor.GREEN + "You selected the tag: " + ChatColor.RESET + displayName);
    }
}
