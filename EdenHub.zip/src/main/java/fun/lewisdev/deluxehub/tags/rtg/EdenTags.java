package fun.lewisdev.deluxehub.tags.rtg;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class EdenTags {
    private final File pluginFolder;
    private FileConfiguration tagsConfig;
    private File tagsFile;
    private final Map<UUID, String> selectedTags = new HashMap<>();

    public EdenTags(File pluginFolder) {
        this.pluginFolder = pluginFolder;
        this.createTagsConfig();
    }

    private void createTagsConfig() {
        if (!this.pluginFolder.exists()) {
            this.pluginFolder.mkdirs();
        }

        this.tagsFile = new File(this.pluginFolder, "tags.yml");
        if (!this.tagsFile.exists()) {
            try {
                this.tagsFile.createNewFile();
                this.tagsConfig = YamlConfiguration.loadConfiguration(this.tagsFile);
                // نمونه مقدار اولیه
                this.tagsConfig.set("tags.default.display", "&7[Default]");
                this.tagsConfig.set("tags.default.permission", "eden.default");
                this.tagsConfig.set("tags.vip.display", "&6[VIP]");
                this.tagsConfig.set("tags.vip.permission", "eden.vip");
                this.saveTagsConfig();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            this.tagsConfig = YamlConfiguration.loadConfiguration(this.tagsFile);
        }
    }

    public FileConfiguration getTagsConfig() {
        return this.tagsConfig;
    }

    public void saveTagsConfig() {
        try {
            this.tagsConfig.save(this.tagsFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void reloadTagsConfig() {
        this.tagsConfig = YamlConfiguration.loadConfiguration(this.tagsFile);
    }

    public void setSelectedTag(UUID uuid, String tag) {
        this.selectedTags.put(uuid, tag);
    }

    public String getSelectedTag(UUID uuid) {
        return this.selectedTags.get(uuid);
    }

    public List<String> getTagsList() {
        if (this.tagsConfig.isConfigurationSection("tags")) {
            return new ArrayList<>(this.tagsConfig.getConfigurationSection("tags").getKeys(false));
        }
        return Collections.emptyList();
    }
}
