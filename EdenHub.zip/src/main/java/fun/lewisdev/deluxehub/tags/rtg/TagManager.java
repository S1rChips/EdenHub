//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package fun.lewisdev.deluxehub.tags.rtg;

import org.bukkit.configuration.file.FileConfiguration;

public class TagManager {
    private final EdenTags plugin;
    private final FileConfiguration tagsConfig;

    public TagManager(EdenTags plugin) {
        this.plugin = plugin;
        this.tagsConfig = plugin.getTagsConfig();
    }

    public void addTag(String name, String display) {
        this.tagsConfig.set("tags." + name + ".display", display);
        this.tagsConfig.set("tags." + name + ".permission", "eden." + name);
        this.plugin.saveTagsConfig();
    }

    public void removeTag(String name) {
        this.tagsConfig.set("tags." + name, (Object)null);
        this.plugin.saveTagsConfig();
    }
}
