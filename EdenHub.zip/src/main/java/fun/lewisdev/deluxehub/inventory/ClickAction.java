package fun.lewisdev.deluxehub.inventory;

import org.bukkit.entity.Player;

public interface ClickAction {
    void execute(final Player p0);
}
