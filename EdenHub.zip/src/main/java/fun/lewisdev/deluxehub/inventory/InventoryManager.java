package fun.lewisdev.deluxehub.inventory;

import fun.lewisdev.deluxehub.DeluxeHubPlugin;
import fun.lewisdev.deluxehub.inventory.inventories.CustomGUI;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class InventoryManager {

    private DeluxeHubPlugin plugin;

    private Map<String, AbstractInventory> inventories;

    // فیلد جدید برای ذخیره آیتم EnderButt (Ender Pearl)
    //private ItemStack enderButt;

    public InventoryManager() {
        inventories = new HashMap<>();
    }

    public void onEnable(DeluxeHubPlugin plugin) {
        this.plugin = plugin;

        loadCustomMenus();

        inventories.values().forEach(AbstractInventory::onEnable);

        plugin.getServer().getPluginManager().registerEvents(new InventoryListener(), plugin);
    }

    private void loadCustomMenus() {

        File directory = new File(plugin.getDataFolder().getAbsolutePath() + File.separator + "menus");

        if (!directory.exists()) {
            directory.mkdir();
            File file = new File(plugin.getDataFolder().getAbsolutePath() + File.separator + "menus", "serverselector.yml");
            try (final InputStream inputStream = this.plugin.getResource("serverselector.yml")) {
                file.createNewFile();
                byte[] buffer = new byte[inputStream.available()];
                inputStream.read(buffer);

                final OutputStream outputStream = new FileOutputStream(file);
                outputStream.write(buffer);
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }

        File[] yamlFiles = new File(plugin.getDataFolder().getAbsolutePath() + File.separator + "menus").listFiles((dir, name) -> name.toLowerCase().endsWith(".yml"));
        if (yamlFiles == null) return;

        for (File file : yamlFiles) {
            String name = file.getName().replace(".yml", "");
            if (inventories.containsKey(name)) {
                plugin.getLogger().warning("Inventory with name '" + file.getName() + "' already exists, skipping duplicate..");
                continue;
            }

            CustomGUI customGUI;
            try {
                customGUI = new CustomGUI(plugin, YamlConfiguration.loadConfiguration(file));
            } catch (Exception e) {
                plugin.getLogger().severe("Could not load file '" + name + "' (YAML error).");
                e.printStackTrace();
                continue;
            }

            inventories.put(name, customGUI);
            plugin.getLogger().info("Loaded custom menu '" + name + "'.");
        }
    }

    public void addInventory(String key, AbstractInventory inventory) {
        inventories.put(key, inventory);
    }

    public Map<String, AbstractInventory> getInventories() {
        return inventories;
    }

    public AbstractInventory getInventory(String key) {
        return inventories.get(key);
    }

    public void onDisable() {
        // اگر نیازی به کاری در onDisable بود اینجا اضافه کنید
    }

    // متد اصلاح شده برای تنظیم آیتم EnderButt
    //public void setEnderButtItem(ItemStack enderButt) {
        //this.enderButt = enderButt.clone();   // کلون گرفتن برای جلوگیری از تغییرات ناخواسته بیرون از کلاس
    //}

    // getter برای دسترسی به آیتم EnderButt
   //public ItemStack getEnderButt() {
        //return enderButt != null ? enderButt.clone() : null;
    //}
}
