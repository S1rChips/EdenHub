package fun.lewisdev.deluxehub.module;

public enum ModuleType {

    ANTI_WDL,
    CHAT_LOCK,
    CUSTOM_COMMANDS,
    DOUBLE_JUMP,
    LAUNCHPAD,
    SCOREBOARD,
    TABLIST,
    ANNOUNCEMENTS,
    WORLD_PROTECT,
    ANTI_SWEAR,
    COMMAND_BLOCK,
    LOBBY,
    VANISH,
    HOLOGRAMS,
    HOTBAR_ITEMS,
    PLAYER_LISTENER,
    PLAYER_OFFHAND_LISTENER

}
